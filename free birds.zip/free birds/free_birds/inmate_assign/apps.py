from django.apps import AppConfig


class InmateAssignConfig(AppConfig):
    name = 'inmate_assign'
