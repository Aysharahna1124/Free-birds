from django.apps import AppConfig


class ActivityConfig(AppConfig):
    name = 'activity'
