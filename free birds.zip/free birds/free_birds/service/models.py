from django.db import models

# Create your models here.
class Service(models.Model):
    service_id = models.AutoField(primary_key=True)
    date = models.DateField()
    service_name = models.CharField(max_length=20)
    details = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'service'
