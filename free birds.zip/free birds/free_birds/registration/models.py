from django.db import models

# Create your models here.
class Registration(models.Model):
    user_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=20)
    address = models.TextField()
    phone_no = models.IntegerField()
    email = models.CharField(max_length=50)
    type = models.CharField(max_length=20)

    class Meta:
        managed = False
        db_table = 'registration'
