from django.conf.urls import url
from staff_registration import views
urlpatterns=[
    url('^reg/',views.staff),
    url('^view/',views.staffview),
    # url('^editstaff/(?P<idd>\w+)',views.editstaff,name="editstaff"),
    url('^delete/(?P<idd>\w+)',views.delete,name='delete'),
    url('^supdate/(?P<idd>\w+)',views.supdate,name='supdate')
]