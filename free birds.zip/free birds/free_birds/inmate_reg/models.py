from django.db import models

# Create your models here.
class InmateReg(models.Model):
    inmate_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=20)
    dob = models.DateField()
    gender = models.CharField(max_length=20)
    health_status = models.CharField(max_length=20)
    education = models.CharField(max_length=20)
    c_id = models.IntegerField()
    hostel_id = models.IntegerField()
    guardian_name = models.CharField(max_length=20)
    guardian_phone = models.IntegerField()
    status = models.CharField(max_length=20)

    class Meta:
        managed = False
        db_table = 'inmate_reg'
