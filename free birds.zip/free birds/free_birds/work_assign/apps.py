from django.apps import AppConfig


class WorkAssignConfig(AppConfig):
    name = 'work_assign'
