from django.shortcuts import render
from about_us.models import AboutUs

# Create your views here.
def abt(request):
    if request.method=="POST":
        obj=AboutUs()
        obj.address=request.POST.get('addres')
        obj.phone=request.POST.get('phone')
        obj.email=request.POST.get('email')
        obj.description=request.POST.get('des')
        obj.save()
    return render(request,'about_us/A_about_us.html')
