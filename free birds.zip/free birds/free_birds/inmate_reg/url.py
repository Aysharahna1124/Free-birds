from django.conf.urls import url
from inmate_reg import views
urlpatterns=[
    url('^vinmate/',views.view_inmate),
    url('^reginm/',views.add_inmate)


]