from django.apps import AppConfig


class InmateRegConfig(AppConfig):
    name = 'inmate_reg'
