from django.db import models

# Create your models here.

class StaffRegistration(models.Model):
    staff_id = models.AutoField(primary_key=True)
    staff_position = models.CharField(max_length=20)
    name = models.CharField(max_length=20)
    address = models.TextField()
    phone = models.CharField(max_length=15)
    gender = models.CharField(max_length=20)
    email = models.CharField(max_length=50)
    qualification = models.CharField(max_length=20)
    salary = models.CharField(max_length=20)
    user_name = models.CharField(max_length=20)
    password = models.CharField(max_length=20)

    class Meta:
        managed = False
        db_table = 'staff_registration'

