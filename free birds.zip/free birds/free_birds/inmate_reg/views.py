from django.shortcuts import render
from inmate_reg.models import InmateReg
# Create your views here.
def view_inmate(request):
    obj=InmateReg.objects.all()
    context={
        'objval':obj,
    }

    return render(request,'inmate_reg/A_view_inmate.html',context)
def add_inmate(request):
    if request.method=="POST":
        obj=InmateReg()
        obj.name=request.POST.get('name')
        obj.gender=request.POST.get('gender')
        obj.dob=request.POST.get('dte')
        obj.health_status=request.POST.get('health')
        obj.status=request.POST.get('status')
        obj.education=request.POST.get('edu')
        obj.hostel_id=1
        obj.guardian_name=request.POST.get('gname')
        obj.guardian_phone=request.POST.get('gphone')
        obj.c_id=1
        obj.save()
    return render(request,'inmate_reg/C_reg_inmate.html')

