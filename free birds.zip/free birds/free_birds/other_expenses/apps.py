from django.apps import AppConfig


class OtherExpensesConfig(AppConfig):
    name = 'other_expenses'
