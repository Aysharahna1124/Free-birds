from django.apps import AppConfig


class StaffRegistrationConfig(AppConfig):
    name = 'staff_registration'
