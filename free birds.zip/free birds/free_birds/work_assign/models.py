from django.db import models

# Create your models here.
class WorkAssign(models.Model):
    work_ass_id = models.AutoField(primary_key=True)
    staff_id = models.IntegerField()
    work = models.CharField(max_length=20)
    date = models.DateField()
    details = models.CharField(max_length=50)
    status = models.CharField(max_length=20)

    class Meta:
        managed = False
        db_table = 'work_assign'

