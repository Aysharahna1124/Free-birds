from django.conf.urls import url
from salary import views
urlpatterns=[
    url('^salary/',views.sal),



]