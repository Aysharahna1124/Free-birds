from django.db import models

# Create your models here.
class RequirementRequest(models.Model):
    req_id = models.AutoField(primary_key=True)
    user_id = models.IntegerField()
    requirement = models.CharField(max_length=20)
    details = models.CharField(max_length=20)

    class Meta:
        managed = False
        db_table = 'requirement_request'
