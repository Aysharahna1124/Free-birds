from django.apps import AppConfig


class RequirementRequestConfig(AppConfig):
    name = 'requirement_request'
