from django.db import models

# Create your models here.
class Salary(models.Model):
    salary_id = models.AutoField(primary_key=True)
    staff_id = models.IntegerField()
    salary = models.IntegerField()
    date = models.DateField()

    class Meta:
        managed = False
        db_table = 'salary'
