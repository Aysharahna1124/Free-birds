from django.shortcuts import render
from salary.models import Salary
from staff_registration.models import StaffRegistration
# Create your views here.
def sal(request):
    obj = StaffRegistration.objects.all()
    context = {
        'objval': obj,
    }
    if(request.method=="POST"):
        obj=Salary()
        obj.staff_id=request.POST.get('s')
        obj.salary=request.POST.get('sal')
        obj.date=request.POST.get('dte')
        obj.save()
    return render(request,'salary/A_issue_salary.html',context)