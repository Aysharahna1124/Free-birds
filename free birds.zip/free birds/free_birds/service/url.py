from django.conf.urls import url
from service import views
urlpatterns = [
    url('^reg/',views.service),
    url('^view/', views.serviceview),
    url('^update/(?P<idd>\w+)',views.update,name='update'),
    url('^sdelete/(?P<idd>\w+)',views.sdelete,name='sdelete')
]