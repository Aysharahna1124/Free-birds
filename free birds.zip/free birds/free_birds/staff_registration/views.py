from django.shortcuts import render

# Create your views here.
from staff_registration.models import StaffRegistration
def staff(request):

    if request.method=="POST":
        obj=StaffRegistration()
        obj.name=request.POST.get('name')
        obj.address=request.POST.get('address')
        obj.gender=request.POST.get('gender')
        obj.email=request.POST.get('email')
        obj.phone=request.POST.get('phone')
        obj.qualification=request.POST.get('qual')
        obj.salary=request.POST.get('salary')
        # obj.type=request.POST.get('type')
        obj.staff_position=request.POST.get('position')
        obj.user_name=request.POST.get('uname')
        obj.password=request.POST.get('pass')
        obj.save()
    return render(request,'staff_registration/A_add_staff.html')
def staffview(request):
    obj=StaffRegistration.objects.all()
    context={
        'objval':obj,
    }

    return render(request,'staff_registration/A_manage_staff.html',context)

def supdate(request,idd):
    obj=StaffRegistration.objects.get(staff_id=idd)
    context={
        'objval':obj,
    }
    if request.method=="POST":
        obj=StaffRegistration.objects.get(staff_id=idd)
        obj.name=request.POST.get('name')
        obj.address=request.POST.get('address')
        obj.gender=request.POST.get('gender')
        obj.email=request.POST.get('email')
        obj.phone=request.POST.get('phone')
        obj.qualification=request.POST.get('qual')
        obj.salary=request.POST.get('salary')
        # obj.type=request.POST.get('type')
        obj.staff_position=request.POST.get('position')
        obj.user_name=request.POST.get('uname')
        obj.password=request.POST.get('pass')
        obj.save()
    return render(request,'staff_registration/A_edit_staff.html',context)

def delete(request,idd):
    obj=StaffRegistration.objects.get(staff_id=idd)
    obj.delete()
    return staffview(request)