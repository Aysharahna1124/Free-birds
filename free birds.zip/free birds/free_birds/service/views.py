from django.shortcuts import render
from service.models import Service
import datetime
# Create your views here.
def service(request):
    if request.method=="POST":
        obj=Service()
        obj.date=datetime.datetime.today()
        obj.service_name=request.POST.get('service')
        obj.details=request.POST.get('det')

        obj.save()
    return render(request,'service/A_add_service.html')

def serviceview(request):
    obj=Service.objects.all()
    context={
        'objval':obj,
    }

    return render(request,'service/A_manage_ser.html',context)


def update(request,idd):
    obj=Service.objects.get(service_id=idd)
    context={
        'objval':obj,
    }
    if request.method=="POST":
        obj=Service.objects.get(service_id=idd)
        obj.date=datetime.datetime.today()
        obj.service_name=request.POST.get('service')
        obj.details=request.POST.get('det')

        obj.save()
    return render(request,'service/update_ser.html',context)

def sdelete(request,idd):
    obj=Service.objects.get(service_id=idd)
    obj.delete()
    return serviceview(request)
