from django.conf.urls import url
from about_us import views
urlpatterns=[
    url('^add/',views.abt)
]