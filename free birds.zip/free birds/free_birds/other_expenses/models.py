from django.db import models

# Create your models here.
class OtherExpenses(models.Model):
    expense_id = models.AutoField(primary_key=True)
    expense = models.CharField(max_length=20)
    date = models.DateField()
    details = models.CharField(max_length=20)

    class Meta:
        managed = False
        db_table = 'other_expenses'
